#ifndef __CALC_H__
#define __CALC_H__

#endif //__CALC_H__

