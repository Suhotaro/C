// author: thismoment
// file: calc.c

#include "calc.h"

