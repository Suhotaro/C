// author: thismoment
// file: test_calc.c

#include <check.h>

#include "calc/calc.h"

Suite * createCalcSuite()
{
	Suite * sCalc;
	TCase * cCore;

	sCalc = suite_create( "Calc" );
	cCore = tcase_create( "Core" );

	//tcase_add_test( cCore, ... );
	
	suite_add_tcase( sCalc, cCore );

	return sCalc;
}

