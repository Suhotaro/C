#ifndef __TEST_CALC_H__
#define __TEST_CALC_H__

#include <check.h>

Suite * createCalcSuite();

#endif //__TEST_CALC_H__

