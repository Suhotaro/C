// author: thismoment
// file: calc.c

#include <stdio.h>
#include <string.h>

#include "calc.h"

int Tokenize( char * args, const char * delimiters )
{
	int sum = 0;
	int n = 0;
	char uselessBuffer[ 256 ] = { 0 };
	char * arg = strtok( args, delimiters );

	while ( arg != NULL )
	{
		if ( sscanf( arg, "%d%s", &n, uselessBuffer ) != 1 )
		{
			sum = -1;
			break;
		}

		if ( n < 0 )
		{
			sum = -1;
			break;
		}

		if ( n <= 1000 )
		{
			sum += n;
		}
		
		arg = strtok( NULL, delimiters );
	}
	
	return sum;
}

int Add( const char * input )
{
	if ( strlen( input ) == 0 )
	{
		return 0;
	}

	char args[ 256 ] = { 0 };
	char customDelimiter[ 16 ] = { 0 };
	char delimiters[] = ",\n";

	int result = sscanf( input, "//%s\n%s", &customDelimiter, &args );

	if ( result == 2 )
	{
		strcpy( delimiters, customDelimiter );
	}
	else
	{
		strcpy( args, input ) ;
	}

	return Tokenize( args, delimiters );
}

