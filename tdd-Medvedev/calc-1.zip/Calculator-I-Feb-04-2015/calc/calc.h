#ifndef __CALC_H__
#define __CALC_H__

int Add( const char * input );

#endif //__CALC_H__

