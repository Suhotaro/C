// author: thismoment
// file: test_main.c

#include <stdlib.h>
#include <check.h>

#include "test_calc.h"

int main( void )
{
	int nFailed = 0;

	Suite * sCalc;
	SRunner * runner;

	sCalc = createCalcSuite();
	runner = srunner_create( sCalc );
	srunner_run_all( runner, CK_NORMAL );
	nFailed = srunner_ntests_failed( runner );
	srunner_free( runner );
	
	return ( nFailed == 0 ) ? EXIT_SUCCESS : EXIT_FAILURE;
}

