// author: thismoment
// file: test_calc.c

#include <check.h>

#include "calc/calc.h"

START_TEST ( Add_EmptyString_ReturnsZero )
{
	int result = Add( "" );

	ck_assert_int_eq( result, 0 );
}
END_TEST

START_TEST ( Add_OneArg_ReturnsArgValue )
{
	int result = Add( "42" );

	ck_assert_int_eq( result, 42 );
}
END_TEST

START_TEST ( Add_TwoArgs_ReturnsSum )
{
	int result = Add( "2,2" );

	ck_assert_int_eq( result, 4 );
}
END_TEST

START_TEST ( Add_ManyArgs_ReturnsSum )
{
	int result = Add( "1,2,3,4,5" );

	ck_assert_int_eq( result, 15 );
}
END_TEST

START_TEST ( Add_EndLineAsDelimiter_ReturnsSum )
{
	int result = Add( "1\n2\n3" );

	ck_assert_int_eq( result, 6 );
}
END_TEST

START_TEST ( Add_MixedDelimiters_ReturnsSum )
{
	int result = Add( "1\n2,3" );

	ck_assert_int_eq( result, 6 );
}
END_TEST

START_TEST ( Add_UnknownDelimiter_ReturnsMinusOne )
{
	int result = Add( "1$2,3" );

	ck_assert_int_eq( result, -1 );
}
END_TEST

START_TEST ( Add_CustomDelimiter_ReturnsSum )
{
	int result = Add( "//;\n1;2;3" );

	ck_assert_int_eq( result, 6 );
}
END_TEST

START_TEST ( Add_NegativeArg_ReturnsMinusOne )
{
	int result = Add( "1,-2,3" );

	ck_assert_int_eq( result, -1 );
}
END_TEST

START_TEST ( Add_ArgGreaterThanThousandIsIgnored_ReturnsSum )
{
	int result = Add( "1,1001,2" );

	ck_assert_int_eq( result, 3 );
}
END_TEST

START_TEST ( Add_LongCustomDelimiter_ReturnsSum )
{
	int result = Add( "//[***]\n1***2***4" );

	ck_assert_int_eq( result, 7 );
}
END_TEST

START_TEST ( Add_ManyLongCustomDelimiters_ReturnsSum )
{
	int result = Add( "//[***][$$$]\n1***2$$$4" );

	ck_assert_int_eq( result, 7 );
}
END_TEST

Suite * createCalcSuite()
{
	Suite * sCalc;
	TCase * cCore;

	sCalc = suite_create( "Calc" );
	cCore = tcase_create( "Core" );

	tcase_add_test( cCore, Add_EmptyString_ReturnsZero );
	tcase_add_test( cCore, Add_OneArg_ReturnsArgValue );
	tcase_add_test( cCore, Add_TwoArgs_ReturnsSum );
	tcase_add_test( cCore, Add_ManyArgs_ReturnsSum );
	tcase_add_test( cCore, Add_EndLineAsDelimiter_ReturnsSum );
	tcase_add_test( cCore, Add_MixedDelimiters_ReturnsSum );
	tcase_add_test( cCore, Add_UnknownDelimiter_ReturnsMinusOne );
	tcase_add_test( cCore, Add_CustomDelimiter_ReturnsSum );
	tcase_add_test( cCore, Add_NegativeArg_ReturnsMinusOne );
	tcase_add_test( cCore, Add_ArgGreaterThanThousandIsIgnored_ReturnsSum );
	tcase_add_test( cCore, Add_LongCustomDelimiter_ReturnsSum );
	tcase_add_test( cCore, Add_ManyLongCustomDelimiters_ReturnsSum );
	
	suite_add_tcase( sCalc, cCore );

	return sCalc;
}

